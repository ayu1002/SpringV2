package com.yash.cmsapp.test;

import java.sql.PreparedStatement;
import java.sql.SQLException;


import com.yash.cmsapp.util.DBUtil;

public class PreparedStatemntTest 
{
	private static PreparedStatement pstmt=null;
	public static void main(String[] args) 
	{
		String sql="insert into users(name, contact, email, address, loginname, password)values('ayu','1234567890','ayu@gmail.com','indore','ayu','ayu123');";
		pstmt=DBUtil.prepareStatement(sql);
		try 
		{
			pstmt.execute();
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		System.out.println("sql query: "+sql);
	}
}
