package com.yash.cmsapp.test;

import com.yash.cmsapp.model.User;
import com.yash.cmsapp.service.UserService;
import com.yash.cmsapp.serviceimpl.UserServiceImpl;

public class InsertServiceTest 
{
	public static void main(String[] args) 
	{

		User user=new User();
		user.setName("archi");
		user.setContact("1234567890");
		user.setEmail("archi@gmail.com");
		user.setAddress("vidisha");
		user.setLoginname("archi");
		user.setPassword("archi123");
		UserService userService= new UserServiceImpl();
		userService.insert(user);
	}
}
