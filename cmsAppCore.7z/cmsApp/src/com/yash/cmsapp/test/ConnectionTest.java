package com.yash.cmsapp.test;

import java.sql.Connection;

import com.yash.cmsapp.util.DBUtil;

public class ConnectionTest
{
	public static void main(String[] args) 
	{
		Connection conn=DBUtil.connect();
		System.out.println("connection: "+conn);
	}
}
