package com.yash.cmsapp.test;

import com.yash.cmsapp.util.DBUtil;

public class DriverLoadTest
{
	public static void main(String[] args) {
		
		//Class c=DBUtil.driverLoad();
		//System.out.println("class from test: "+c);
	}
}
