package com.yash.cmsapp.test;

import com.yash.cmsapp.dao.UserDAO;
import com.yash.cmsapp.daoimpl.UserDAOImpl;
import com.yash.cmsapp.model.User;

public class InsertDAOTest 
{
	public static void main(String[] args) 
	{
		User user=new User();
		user.setName("saloni");
		user.setContact("1234567890");
		user.setEmail("saloni@gmail.com");
		user.setAddress("ujjain");
		user.setLoginname("saloni");
		user.setPassword("saloni123");
		UserDAO dao=new UserDAOImpl();
		dao.insert(user);
	}
}
