package com.yash.cmsapp.daoimpl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.yash.cmsapp.dao.ContactDAO;
import com.yash.cmsapp.model.Contact;
import com.yash.cmsapp.util.DBUtil;

public class ContactDAOImpl implements ContactDAO
{
	private static Logger logger=Logger.getLogger("ContactDAOImpl.class");
	@Override
	public void insert(Contact contact) 
	{
		String sql="insert into contact(userid, name, contact, email, address)values(?,?,?,?,?)";
		PreparedStatement pstmt=DBUtil.prepareStatement(sql);
		try 
		{
			pstmt.setInt(1, contact.getUserid());
			pstmt.setString(2, contact.getName());
			pstmt.setString(3, contact.getContact());
			pstmt.setString(4, contact.getEmail());
			pstmt.setString(5, contact.getAddress());
			pstmt.execute();
			logger.info("contact added successfully");
		}
		
		catch(SQLException e)
		{
			e.getMessage();
		}
		
	}
	
	@Override
	public boolean delete(int contactId) 
	{
		String sql="DELETE FROM contact WHERE id=?";
		PreparedStatement pstmt=DBUtil.prepareStatement(sql);
		try 
		{
			pstmt.setInt(1, contactId);
			int check=pstmt.executeUpdate();
			if(check!=1)
			{
				return false;
			}
		}
		catch(Exception e)
		{
			e.getMessage();
		}
		return true;
	}
	
	@Override
	public Contact forEditContact(int contactId)
	{
		String sql="SELECT * FROM contact where id=?";
		Contact contact=null;
		try
		{
			PreparedStatement pstmt=DBUtil.prepareStatement(sql);
			pstmt.setInt(1, contactId);
			ResultSet rs=pstmt.executeQuery();
			contact=new Contact();
			if(rs.next())
			{
				contact.setId(rs.getInt("id"));
				contact.setUserid(rs.getInt("userid"));
				contact.setName(rs.getString("name"));
				contact.setContact(rs.getString("contact"));
				contact.setEmail(rs.getString("email"));
				contact.setAddress(rs.getString("address"));
			}
		}
		catch(SQLException e)
		{
			e.getMessage();
		}
		return contact;
	}
	
	List<Contact> contactList;
	@Override
	public List<Contact> showListDAO(int tempid) 
	{
		String sql="SELECT * FROM contact where userid=?";
		Contact contact;
		try
		{
			PreparedStatement pstmt=DBUtil.prepareStatement(sql);
			pstmt.setInt(1, tempid);
			ResultSet rs=pstmt.executeQuery();
			contactList=new ArrayList<>();
			while(rs.next())
			{
				contact=new Contact();
				contact.setId(rs.getInt("id"));
				contact.setUserid(rs.getInt("userid"));
				contact.setName(rs.getString("name"));
				contact.setContact(rs.getString("contact"));
				contact.setEmail(rs.getString("email"));
				contact.setAddress(rs.getString("address"));
				contactList.add(contact);
			}
		}
		catch(SQLException e)
		{
			e.getMessage();
		}
		logger.info("list of contactObject from prepareContactDAOImpl: "+contactList);
		return contactList;	
	}
	
	
	@Override
	public boolean update(Contact contact)
	{
		{
			String sql="update contact set name=?,contact=?,email=?,address=? WHERE id=?";
			System.out.println(sql);
			PreparedStatement pstmt=DBUtil.prepareStatement(sql);
			try 
			{
				pstmt.setString(1, contact.getName());
				pstmt.setString(2, contact.getContact());
				pstmt.setString(3, contact.getEmail());
				pstmt.setString(4, contact.getAddress());
				pstmt.setInt(5, contact.getId());
				int check=pstmt.executeUpdate();
				if(check!=1)
				{
					return false;
				}
			}
			catch(Exception e)
			{
				e.getMessage();
			}
			return true;
		}
	}

}
