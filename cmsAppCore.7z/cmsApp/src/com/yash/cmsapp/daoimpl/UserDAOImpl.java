package com.yash.cmsapp.daoimpl;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.apache.log4j.Logger;

import com.yash.cmsapp.dao.UserDAO;
import com.yash.cmsapp.model.User;
import com.yash.cmsapp.util.DBUtil;

/**
 * This class implements UserDAO Interface and Overrides its methods for providing body to it.
 * This class performs all the database related tasks in our application related to user. 
 * @author ayushi.jain
 *
 */
public class UserDAOImpl implements UserDAO
{
	private static Logger logger=Logger.getLogger("UserDAOImpl.class");
	
	/**
	 * This method inserts data in user table in our database.
	 * @param user
	 */
	@Override
	public void insert(User user)
	{
		String sql="insert into users(name, contact, email, address, loginname, password)values(?,?,?,?,?,?)";
		PreparedStatement pstmt=DBUtil.prepareStatement(sql);
		try 
		{
			pstmt.setString(1, user.getName());
			pstmt.setString(2, user.getContact());
			pstmt.setString(3, user.getEmail());
			pstmt.setString(4, user.getAddress());
			pstmt.setString(5, user.getLoginname());
			pstmt.setString(6, user.getPassword());
			pstmt.execute();
			logger.info("user added successfully");
		}
		
		catch(SQLException e)
		{
			e.getMessage();
		}
	}
	
	@Override
	public void delete(Integer userid) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update(Integer userid) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List list() {
		// TODO Auto-generated method stub
		return null;
	}

	
}
