package com.yash.cmsapp.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.yash.cmsapp.model.User;
import com.yash.cmsapp.service.UserService;
import com.yash.cmsapp.serviceimpl.UserServiceImpl;

/**
 * Servlet implementation class UserLoginController
 */
@WebServlet("/UserLoginController")
public class UserLoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private static Logger logger=Logger.getLogger("AddContactController.class");
	/**
	 * userService is reference of UserService Interface.
	 */
	private UserService userService;
	
	/**
	 * This constructor creates object of UserServiceImpl.
	 */
	public UserLoginController()
	{
		userService=new UserServiceImpl();
		logger.info("from UserLoginController:- "+userService);
	}
       
	/**
	 * This method passes data from form to service.
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String name=request.getParameter("loginname");
		String pwd=request.getParameter("password");
		//userService=new UserServiceImpl();
		User user=userService.userAuthentication(name, pwd);
		//System.out.println("pwd from controller: "+pwd);
		if(user!=null){
		HttpSession session=request.getSession(true);
		session.setAttribute("name", user.getName());
		session.setAttribute("user", user);
		session.setAttribute("userid", user.getId());
		response.sendRedirect("./home.jsp?msg='User logged in Successfully'");
		}else{
			response.sendRedirect("./index.jsp?err='Username/password invalid'");
		}
		
	}

}
