package com.yash.cmsapp.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.yash.cmsapp.model.Contact;
import com.yash.cmsapp.service.ContactService;
import com.yash.cmsapp.serviceimpl.ContactServiceImpl;

/**
 * Servlet implementation class PrepareContactListController
 */
@WebServlet("/PrepareContactListController")
public class PrepareContactListController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private ContactService contactService;
	private static Logger logger=Logger.getLogger("PrepareContactListController.class");
	
	public PrepareContactListController()
	{
		contactService=new ContactServiceImpl(); 
		logger.info("from PrepareContactListController:- "+contactService);
	}
       

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		HttpSession session=request.getSession();
		int tempid=(int)session.getAttribute("userid");
		List<Contact> contactList=contactService.showList(tempid);
		request.setAttribute("contactList", contactList);
		getServletContext().getRequestDispatcher("/contactListDisplayMain.jsp?act='cadd'").forward(request, response);
	
	}

}
