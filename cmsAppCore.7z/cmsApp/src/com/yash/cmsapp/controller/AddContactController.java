package com.yash.cmsapp.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.yash.cmsapp.model.Contact;
import com.yash.cmsapp.service.ContactService;
import com.yash.cmsapp.serviceimpl.ContactServiceImpl;

/**
 * Servlet implementation class AddContactController
 */
@WebServlet("/AddContactController")
public class AddContactController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	private ContactService contactService;
	private static Logger logger=Logger.getLogger("AddContactController.class");
	public AddContactController()
	{
		contactService=new ContactServiceImpl();
		logger.info("from AddContactController:- "+contactService);
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		System.out.println(request.getParameter("id"));
		HttpSession session=request.getSession();
		Contact contact=new Contact(); 
		contact.setUserid((int)session.getAttribute("userid"));
		contact.setName(request.getParameter("name"));
		contact.setContact(request.getParameter("contact"));
		contact.setEmail(request.getParameter("email"));
		contact.setAddress(request.getParameter("address"));
		if(request.getParameter("id")==""){
			contactService.insert(contact);
			getServletContext().getRequestDispatcher("/PrepareContactListController").forward(request, response);
		}
		else{
			contact.setId(Integer.parseInt(request.getParameter("id")));
			contactService.update(contact);
			logger.info("Contact Updated..........!!!!!!!!!!");
			getServletContext().getRequestDispatcher("/PrepareContactListController").forward(request, response);
		}
		
	}

}
