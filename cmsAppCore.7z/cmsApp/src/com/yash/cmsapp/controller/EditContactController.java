package com.yash.cmsapp.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.yash.cmsapp.model.Contact;
import com.yash.cmsapp.service.ContactService;
import com.yash.cmsapp.serviceimpl.ContactServiceImpl;


/**
 * Servlet implementation class EditContactController
 */
@WebServlet("/EditContactController")
public class EditContactController extends HttpServlet {
	private static final long serialVersionUID = 1L;
      
	private ContactService contactService;
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EditContactController()
    {
    	contactService=new ContactServiceImpl(); 
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		Integer contactIdInteger=Integer.parseInt(request.getParameter("id"));
		int contactId= contactIdInteger.intValue();
		Contact contact=contactService.forEdit(contactId);
		System.out.println(contact.getId());
		request.setAttribute("con", contact);
		request.getRequestDispatcher("addContact.jsp").forward(request, response);
		
	}


}
