package com.yash.cmsapp.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.yash.cmsapp.model.User;
import com.yash.cmsapp.service.UserService;
import com.yash.cmsapp.serviceimpl.UserServiceImpl;

/**
 * UserServiceController is a servlet that extends HttpServlet used for controlling data.
 * @author ayushi.jain
 *
 */
@WebServlet("/UserRegistrationController")
public class UserRegistrationController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private static Logger logger=Logger.getLogger("UserRegistrationController.class");
	/**
	 * userService is reference of UserService Interface.
	 */
	private UserService userService;
	
	/**
	 * This constructor creates object of UserServiceImpl.
	 */
	public UserRegistrationController()
	{
		userService=new UserServiceImpl();
		logger.info("from UserRegistrationController:- "+userService);
	}
	
      /**
       *This method passes the data from form to service.  
       */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		User user=new User();
		//PrintWriter out=response.getWriter();
		user.setName(request.getParameter("name"));
		user.setContact(request.getParameter("contact"));
		user.setEmail(request.getParameter("email"));
		user.setAddress(request.getParameter("address"));
		user.setLoginname(request.getParameter("loginname"));
		user.setPassword(request.getParameter("password"));
		userService.insert(user);
		response.sendRedirect("./index.jsp?msg='User Registered Successfully'");
	}

}
