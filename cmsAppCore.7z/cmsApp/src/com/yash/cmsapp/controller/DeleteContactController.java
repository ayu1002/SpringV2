package com.yash.cmsapp.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.yash.cmsapp.service.ContactService;
import com.yash.cmsapp.serviceimpl.ContactServiceImpl;

/**
 * Servlet implementation class DeleteContactController
 */
@WebServlet("/DeleteContactController")
public class DeleteContactController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	private static Logger logger=Logger.getLogger("DeleteContactController.class");
	private ContactService contactService;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DeleteContactController() 
    {
    	contactService=new ContactServiceImpl();
    	logger.info("from DeleteContactController:- "+contactService);
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		int contactId=Integer.parseInt(request.getParameter("id"));
		boolean check=contactService.delete(contactId);
		if(check==true)
		{
			System.out.println("contact deleted");
		//getServletContext().getRequestDispatcher("/PrepareContactListController").forward(request, response);
			getServletContext().getRequestDispatcher("/PrepareContactListController").forward(request, response);
		}
		else
		{
			System.out.println("contact not deleted");
			response.sendRedirect("./contactListDisplayMain.jsp");
		}
	}

}
