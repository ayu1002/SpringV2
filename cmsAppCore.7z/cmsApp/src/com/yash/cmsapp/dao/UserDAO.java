package com.yash.cmsapp.dao;
import java.util.List;

import com.yash.cmsapp.model.User;
/**
 * This interface will perform the operations relayted to users.
 * @author ayushi.jain
 *
 */
public interface UserDAO 
{
	/**
	 * This will add user object in DB
	 * @param user
	 */
	public void insert(User user);
	
	/**
	 * This will delete user record from DB based on provided user
	 * @param userid
	 */
	public void delete(Integer userid);
	
	/**
	 * This will update user record in DB based on provided userid
	 */
	public void update(Integer userid);
	
	/**
	 * This will list all users from table from DB.
	 * @return
	 */
	public List list();
	
}
