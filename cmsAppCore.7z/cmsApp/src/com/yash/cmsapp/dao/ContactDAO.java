package com.yash.cmsapp.dao;

import java.util.List;

import com.yash.cmsapp.model.Contact;

public interface ContactDAO 
{
	public void insert(Contact contact);
	
	public boolean delete(int contactId);
	
	public Contact forEditContact(int contactId);
	
	public List<Contact> showListDAO(int tempid);
	
	public boolean update(Contact contact);
}
