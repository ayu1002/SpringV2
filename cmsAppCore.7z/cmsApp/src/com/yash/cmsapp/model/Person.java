package com.yash.cmsapp.model;
/**
 * This class contains attributes of person and their getters setters as well.
 * @author ayushi.jain
 *
 */
public class Person 
{

	/**
	 * id of user
	 */
	private int id;
	/**
	 * name of person
	 */
	private String name;
	
	/**
	 * contact of person
	 */
	private String contact;
	
	/**
	 * email of person
	 */
	private String email;
	
	/**
	 * address of person
	 */
	private String address;
	
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
}
