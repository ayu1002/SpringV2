package com.yash.cmsapp.model;
/**
 * This class contains attributes of user and their getters and setters as well and also extends super class & has its properties.
 * @author ayushi.jain
 *
 */
public class User extends Person
{
	/**
	 * status of user
	 */
	private int status;

	/**
	 * role of user
	 */
	private int role;
	
	/**
	 * loginname of user
	 */
	private String loginname;
	
	/**
	 * password of user
	 */
	private String password;
	
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public int getRole() {
		return role;
	}
	public void setRole(int role) {
		this.role = role;
	}
	public String getLoginname() {
		return loginname;
	}
	public void setLoginname(String loginname) {
		this.loginname = loginname;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
}
