package com.yash.cmsapp.model;
/**
 * This class contains attributes of user and their getters and setters as well and also extends super class & has its properties.
 * @author ayushi.jain
 *
 */
public class Contact extends Person
{
	/**
	 * userid of user.
	 */
	
	private int userid;

	public int getUserid() {
		return userid;
	}

	public void setUserid(int userid) {
		this.userid = userid;
	}
	
}
