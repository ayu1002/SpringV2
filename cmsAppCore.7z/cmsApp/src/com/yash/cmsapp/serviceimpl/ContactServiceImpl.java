package com.yash.cmsapp.serviceimpl;

import java.util.List;

import com.yash.cmsapp.dao.ContactDAO;
import com.yash.cmsapp.daoimpl.ContactDAOImpl;
import com.yash.cmsapp.model.Contact;
import com.yash.cmsapp.service.ContactService;

public class ContactServiceImpl implements ContactService 
{

	private ContactDAO contactDAO;
	
	public ContactServiceImpl() 
	{
		contactDAO=new ContactDAOImpl();
	}

	@Override
	public void insert(Contact contact) 
	{
		contactDAO.insert(contact);
		
	}
	
	@Override
	public boolean delete(int contactId) 
	{
		
		boolean check=contactDAO.delete(contactId);
		return check;
	}
	
	@Override
	public Contact forEdit(int id) 
	{
		return contactDAO.forEditContact(id);
	}

	@Override
	public List<Contact> showList(int tempid) 
	{
		return contactDAO.showListDAO(tempid);
	}
	
	@Override
	public boolean update(Contact contact) 
	{
		return contactDAO.update(contact);
		
	}

}
