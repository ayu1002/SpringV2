package com.yash.cmsapp.serviceimpl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.yash.cmsapp.dao.UserDAO;
import com.yash.cmsapp.daoimpl.UserDAOImpl;
import com.yash.cmsapp.model.User;
import com.yash.cmsapp.service.UserService;
import com.yash.cmsapp.util.DBUtil;

/**
 * This class implements UserService Interface and Overrides its methods for providing body to it.
 * This class performs all the service related tasks in our application related to user. 
 * @author ayushi.jain
 *
 */
public class UserServiceImpl implements UserService
{
	/**
	 * userDao is reference for userDAO Interface.
	 */
	private UserDAO userDao;
	
	/**
	 * UserServiceImpl Constructor creates object of DAO layer. 
	 */
	public  UserServiceImpl()
	{
		userDao=new UserDAOImpl();
	}
	
	
	/**
	 * registerUser methods registers user
	 */
	@Override
	public void insert(User user) 
	{
		userDao.insert(user);
	}
	
	/**
	 * This will authenticate user and login the particular user
	 */
	@Override
	public User userAuthentication(String loginname, String password) 
	{
	    User user=null;
		String sql="select * from users where loginname=? and password=?;";
		PreparedStatement pstmt=DBUtil.prepareStatement(sql);
		try 
		{
			System.out.println("in try of userserviceimpl");
			System.out.println("loginname: "+loginname);
			System.out.println("password: "+password);
			pstmt.setString(1, loginname);
			pstmt.setString(2, password);
			ResultSet rs=pstmt.executeQuery();
			if(rs.next())
			{
				user=new User();
				user.setId(rs.getInt("id"));
				user.setName(rs.getString("name"));
				user.setContact(rs.getString("contact"));
				user.setEmail(rs.getString("email"));
				user.setAddress(rs.getString("address"));
				user.setStatus(rs.getInt("status"));
				user.setRole(rs.getInt("role"));
				user.setLoginname(rs.getString("loginname"));
				user.setPassword(rs.getString("password"));
				System.out.println("login successfully");
			}
			else
			{
				System.out.println("please enter correct loginname and password");
			}
		} 
		catch (SQLException e) 
		{	
			e.getMessage();
		}
		return user;
		
	}
	
	

}
