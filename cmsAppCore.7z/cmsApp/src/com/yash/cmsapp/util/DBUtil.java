package com.yash.cmsapp.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.apache.log4j.Logger;

/**
 * DbUtil class is a utility class, and whenever any database related operation is performed, we need to use it for loading the 
 * driver and establishing connection and for preparedStatement as well. 
 * @author ayushi.jain
 *
 */
public class DBUtil 
{

	private static Logger logger=Logger.getLogger("DBUtil.class");
	/**
	 * conn is the Connection object for establishing connection with database name. 
	 */
	private static Connection conn=null;
	
	/**
	 * url is String type passed to getConnection method for establishing connection with particular database.
	 */
	private static String url="jdbc:mysql://localhost/cmsapp";
	
	/**
	 * user is same as the username we have provided to our database.
	 */
	private static String user="root";
	
	/**
	 * pwd is same as the password we have provided to our database.
	 */
	private static String pwd="root";
	
	/**
	 *pstmt is used for passing query in javacode for database. 
	 */
	private static PreparedStatement pstmt=null;
	
	private static String sql;
	
	/**
	 * static block will start working for loading driver as DBUtil is called.
	 */
	static
	{
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");
			
		} 
		catch (ClassNotFoundException e) {
			
			e.getMessage();
		}
	}
	
	/**
	 * This method establishes connection with particular database.
	 * @return Connection
	 */
	public static Connection connect()
	{
		try
		{
			conn=DriverManager.getConnection(url, user, pwd);
			logger.info("Connection:- "+conn);
		} 
		catch (SQLException e) {
			
			e.getMessage();
		}
		return conn;
	}
	
	
	
	
	public static Connection jndiConnect()
	{
		Context initContext;
		try
		{
			initContext = new InitialContext();
			Context envContext = (Context) initContext.lookup("java:comp/env");
			DataSource ds = (DataSource) envContext.lookup("jdbc/cmsapp");
			conn = ds.getConnection();
		}
		catch (NamingException | SQLException e) {
			
			e.printStackTrace();
		}
		return conn;
		
	}
	
	/**
	 * This method is used to fire query for our database, any action we want to perform in database is done by this method.
	 * @param sql
	 * @return PreparedStatement
	 */
	public static PreparedStatement prepareStatement(String sql)
	{
		jndiConnect();
		try 
		{
			pstmt=conn.prepareStatement(sql);
			logger.info("Prepared:- "+pstmt);
		} 
		catch (SQLException e) 
		{	
			e.getMessage();
		}
		return pstmt;
	}
	
	/**
	 * This method closes the connection of Connection.
	 */
	public static void closeConnection()
	{
		try 
		{
			conn.close();
		}
		catch (SQLException e) 
		{	
			e.getMessage();
		}
	}
	
	/**
	 * This method closes PreparedStatement.
	 */
	public static void closePreparedStatement()
	{
		try
		{
			pstmt.close();
		}
		catch (SQLException e) 
		{
			e.getMessage();
		}
	}
}
