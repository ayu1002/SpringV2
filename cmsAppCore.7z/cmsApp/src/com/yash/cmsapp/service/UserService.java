package com.yash.cmsapp.service;

import com.yash.cmsapp.model.User;

/**
 * This will perform all service related task on user.
 * @author ayushi.jain
 *
 */
public interface UserService 
{
	/**
	 * This will register user.
	 * @param user object
	 */
	public void insert(User user);
	
	/**
	 * This will authenticate user based on loginname and password.
	 * @param loginname
	 * @param password
	 * @return user record if user is authenticate.
	 */
	public User userAuthentication(String loginname, String password);
}
