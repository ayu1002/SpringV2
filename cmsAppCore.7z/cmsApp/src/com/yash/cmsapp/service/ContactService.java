package com.yash.cmsapp.service;

import java.util.List;

import com.yash.cmsapp.model.Contact;

public interface ContactService 
{
	public void insert(Contact contact);
	
	public boolean delete(int contactId);
	
	public Contact forEdit(int id);
	
	public List<Contact> showList(int tempid);
	
	public boolean update(Contact contact);
}
