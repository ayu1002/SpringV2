package com.yash.dams.daoimpl;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.yash.dams.dao.UserDAO;
import com.yash.dams.model.User;
import com.yash.dams.rowmapper.UserMapper;

@Repository
public class UserDaoImpl implements UserDAO {
	Connection con;
	private JdbcTemplate jdbcTemplate;
	@Autowired
	private DataSource dataSource;
	
	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate=new JdbcTemplate(dataSource);
	}
	public int save(User user) {
		boolean result=isUserExist(user.getLoginname());
		int var=0;
		if(result==true) {
			return var;
		}
		try {
			con = dataSource.getConnection();
			String sql = "insert into users(first_name, last_name, contact, email, loginname, password)values(?,?,?,?,?,?)";
			Object[] param=new Object[] {
				user.getFirst_name(),
				user.getLast_name(),
				user.getContact(),
				user.getEmail(),
				user.getLoginname(),
				user.getPassword()
			};
			jdbcTemplate.update(sql, param);
		} 
		catch (SQLException e1) {
			e1.printStackTrace();
		}
		return var+1;
	}
	
	
	public boolean isUserExist(String loginname) {
		boolean result=false;
		String sql="select count(*) from users where loginname =?";
		int count=jdbcTemplate.queryForObject(sql, Integer.class, loginname);
		//int count=jdbcTemplate.queryForObject(sql, new Object[] {loginname}, Integer.class);
		//System.out.println("count: "+count);
		if(count!=0) {
			result=true;
		}
		return result;
	}
	
	public User login(String loginname, String password) {
		try {
			con=dataSource.getConnection();
			String sql = "select * from users where loginname='" + loginname + "' and password='" +password+"'";
		   // List<User> user = jdbcTemplate.query(sql, new UserMapper());
			User user=jdbcTemplate.queryForObject(sql, new UserMapper());
		    //return users.size() > 0 ? users.get(0) : null;
			return user;
		} 
		catch (SQLException e) {
			
			e.printStackTrace();
		}
		return null;
	}
	public List<User> showList() {
		try {
			con=dataSource.getConnection();
			String sql="select * from users";
			return jdbcTemplate.query(sql, new UserMapper());
		}
		catch (SQLException e) {	
			e.printStackTrace();
		}
		return null;
	}
	public int delete(Integer id) {
		try {
			con=dataSource.getConnection();
			String sql="delete from users where id=?";
			return jdbcTemplate.update(sql, id);
		} 
		catch (SQLException e) {
			e.printStackTrace();
		}
		return 0;
	}
	public int update(User user) {
		// TODO Auto-generated method stub
		return 0;
	}
	

}
