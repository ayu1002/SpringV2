package com.yash.dams.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.dams.dao.UserDAO;
import com.yash.dams.model.User;
import com.yash.dams.service.UserService;

@Service
public class UserServiceImpl implements UserService {
	@Autowired
	private UserDAO userDAO;

	public int registerUser(User user) {
		return userDAO.save(user);
	}
	
	public User loginUser(String loginname, String password) {
		return userDAO.login(loginname, password);
	}

	public List<User> showList() {
		return userDAO.showList();
	}

	public int delete(Integer id) {
		return userDAO.delete(id);
	}
	
}
