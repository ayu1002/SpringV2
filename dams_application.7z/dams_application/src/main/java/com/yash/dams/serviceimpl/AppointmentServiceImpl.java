package com.yash.dams.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.dams.dao.AppointmentDAO;
import com.yash.dams.model.Appointment;
import com.yash.dams.service.AppointmentService;

@Service
public class AppointmentServiceImpl implements AppointmentService {

	@Autowired
	private AppointmentDAO appointmentDAO;
	public int bookAppointment(Appointment appointment) {
		return appointmentDAO.bookAppointment(appointment); 
	}
	public List<Appointment> showList() {
		return appointmentDAO.showList();
	}
	public List<Appointment> myBookings(Integer userid) {
		return appointmentDAO.myBookings(userid);
	}
}
