package com.yash.dams.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.dams.dao.AppointmentDAO;
import com.yash.dams.model.Appointment;
import com.yash.dams.service.AppointmentService;

@Service
public class AppointmentServiceImpl implements AppointmentService {

	@Autowired
	private AppointmentDAO appointmentDAO;
	public int bookAppointment(Appointment appointment) {
		return appointmentDAO.bookAppointment(appointment); 
	}

}
