package com.yash.dams.model;

import java.sql.Date;
import java.sql.Time;


public class Appointment {
	private int id;
	private int userid;
	private Date date_created;
	private Time start_time;
	private int slot;
	private Time end_time;
	private Time end_time_expected;
	private String fee;
	private String discount;
	private String final_fee;
	private int cancel;
	private String cancel_reason;
	private int status;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getUserid() {
		return userid;
	}
	public void setUserid(int userid) {
		this.userid = userid;
	}
	public Date getDate_created() {
		return date_created;
	}
	public void setDate_created(Date date_created) {
		this.date_created = date_created;
	}
	public Time getStart_time() {
		return start_time;
	}
	public void setStart_time(Time start_time) {
		this.start_time = start_time;
	}
	public int getSlot() {
		return slot;
	}
	public void setSlot(int slot) {
		this.slot = slot;
	}
	public Time getEnd_time() {
		return end_time;
	}
	public void setEnd_time(Time end_time) {
		this.end_time = end_time;
	}
	public Time getEnd_time_expected() {
		return end_time_expected;
	}
	public void setEnd_time_expected(Time end_time_expected) {
		this.end_time_expected = end_time_expected;
	}
	public String getFee() {
		return fee;
	}
	public void setFee(String fee) {
		this.fee = fee;
	}
	public String getDiscount() {
		return discount;
	}
	public void setDiscount(String discount) {
		this.discount = discount;
	}
	public String getFinal_fee() {
		return final_fee;
	}
	public void setFinal_fee(String final_fee) {
		this.final_fee = final_fee;
	}
	public int getCancel() {
		return cancel;
	}
	public void setCancel(int cancel) {
		this.cancel = cancel;
	}
	public String getCancel_reason() {
		return cancel_reason;
	}
	public void setCancel_reason(String cancel_reason) {
		this.cancel_reason = cancel_reason;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	
}
