package com.yash.dams.service;

import com.yash.dams.model.Appointment;

public interface AppointmentService {
	public int bookAppointment(Appointment appointment);
}
