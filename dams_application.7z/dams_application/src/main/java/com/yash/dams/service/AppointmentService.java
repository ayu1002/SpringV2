package com.yash.dams.service;

import java.util.List;

import com.yash.dams.model.Appointment;

public interface AppointmentService {
	public int bookAppointment(Appointment appointment);
	public List<Appointment> showList();
	public List<Appointment> myBookings(Integer userid);
}
