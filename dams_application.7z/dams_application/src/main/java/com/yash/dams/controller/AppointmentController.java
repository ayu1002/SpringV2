package com.yash.dams.controller;

import java.sql.Date;
import java.util.List;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.yash.dams.model.Appointment;
import com.yash.dams.model.User;
import com.yash.dams.service.AppointmentService;

@Controller
@RequestMapping("/appointment")
public class AppointmentController {
	@Autowired
	private AppointmentService appointmentService;
	@RequestMapping(value="/bookAppointment.htm", method=RequestMethod.GET)
	public String bookAppointment() {
		return "bookAppointment";
	}
	
	@RequestMapping(value="/processAppointmentBooking.htm", method=RequestMethod.POST)
	public String processBookAppointment(Model model, @RequestParam Date date_created, @RequestParam String start_time, @RequestParam String end_time, HttpSession session) {
		Integer id=(Integer) session.getAttribute("userId");
		Appointment appointment=new Appointment();
		appointment.setUserid(id);
		appointment.setDate_created(date_created);
		appointment.setStart_time(start_time);
		appointment.setEnd_time(end_time);
		int var=appointmentService.bookAppointment(appointment);
		if(var!=0) {
			return "redirect:../user/home.htm";
		}
		return "bookAppointment";
	}
	
	@RequestMapping(value="/listAppointment.htm", method=RequestMethod.GET)
	public String showUsers(Model model) {
		List<Appointment> appointments=appointmentService.showList();
		model.addAttribute("appointments", appointments);
		return "listAppointment";
	}
	
	@RequestMapping(value="/myBookings.htm", method=RequestMethod.GET)
	public String myBookings(Model model, HttpSession session) {
		Integer id=(Integer) session.getAttribute("userId");
		List<Appointment> appointments=appointmentService.myBookings(id);
		model.addAttribute("appointments", appointments);
		return "myBookings";
	}
	
}
