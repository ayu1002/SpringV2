package com.yash.dams.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.yash.dams.model.Appointment;
import com.yash.dams.service.AppointmentService;
import com.yash.dams.service.UserService;

@Controller
@RequestMapping("/user/appointment")
public class AppointmentController {
	@Autowired
	private AppointmentService appointmentService;
	@RequestMapping(value="/bookAppointment.htm", method=RequestMethod.GET)
	public String bookAppointment() {
		return "bookAppointment";
	}
	
	@RequestMapping(value="/processAppointmentBooking.htm", method=RequestMethod.POST)
	public String processBookAppointment(@ModelAttribute("appointment") Appointment appointment) {
		int var=appointmentService.bookAppointment(appointment);
		if(var!=0) {
			return "redirect:./home.htm";
		}
		return "bookAppointment";
	}
	
}
