package com.yash.dams.dao;

import java.util.List;

import com.yash.dams.model.User;

public interface UserDAO {
	public int save(User user);
	public boolean isUserExist(String loginname);
	public User login(String loginname, String password);
	public List<User> showList();
	public int delete(Integer userId);
	public int update(User user);
}
