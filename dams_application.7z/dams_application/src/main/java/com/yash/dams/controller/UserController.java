package com.yash.dams.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.yash.dams.model.User;
import com.yash.dams.service.UserService;

@Controller
@RequestMapping("/user")
public class UserController {

	@Autowired
	private UserService userService;
	@RequestMapping(value="/home.htm", method=RequestMethod.GET)
	public String homePage() {
		return "home";
	}
	
	@RequestMapping(value="/userRegistration.htm", method=RequestMethod.GET)
	public String showUserRegistration() {
		return "userRegistration";
	}
	
	@RequestMapping(value="/processUserRegistration.htm", method=RequestMethod.POST)
	public String processUserRegistration(@ModelAttribute("user") User user, BindingResult result) {
		int var=userService.registerUser(user);
		if(var!=0) {
			return "redirect:./home.htm";
		}
		return "userRegistration";
	}
	
	@RequestMapping(value="/login.htm", method=RequestMethod.GET)
	public String login() {
		return "login";
	}
	
	@RequestMapping(value="/processloginUser.htm", method=RequestMethod.POST)
	public String processloginUser(Model model, @RequestParam String loginname, @RequestParam String password, HttpSession session) {
		User user=userService.loginUser(loginname, password);
		session.setAttribute("user", user);
		session.setAttribute("userId", user.getId());
		System.out.println(session.getId());
		if(user!=null) {
			
			return "redirect:./home.htm"; 
		}
		return "login";
	}
	
	@RequestMapping(value="/showUsers.htm", method=RequestMethod.GET)
	public String showUsers(Model model) {
		List<User> users=userService.showList();
		model.addAttribute("users", users);
		return "showUsers";
	}
	
	@RequestMapping(value="/deleteUser.htm", method=RequestMethod.GET)
	public String deleteUser(HttpSession session) {
		Integer id=(Integer) session.getAttribute("userId");
		Integer result=userService.delete(id);
		if(result!=null)
		return "showUsers";
		return "showUsers";
	}
	@RequestMapping(value="/logout.htm", method=RequestMethod.GET)
	public String forLogout(HttpSession session) {
		session.getAttribute("user");
		session.getAttribute("userId");
		System.out.println(session.getId());
		session.invalidate();
		System.out.println(session.getId());
		return "login";
	}
	
}
