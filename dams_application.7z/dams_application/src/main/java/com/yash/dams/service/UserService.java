package com.yash.dams.service;

import java.util.List;

import com.yash.dams.model.User;

public interface UserService {
	public int registerUser(User user);
	public User loginUser(String loginname, String password);
	public List<User> showList();
	public int delete(Integer id);
}
