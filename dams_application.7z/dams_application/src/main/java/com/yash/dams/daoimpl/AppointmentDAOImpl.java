package com.yash.dams.daoimpl;

import java.sql.Connection;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.yash.dams.dao.AppointmentDAO;
import com.yash.dams.model.Appointment;

@Repository
public class AppointmentDAOImpl implements AppointmentDAO {
	private Connection con;
	private JdbcTemplate jdbcTemplate;
	@Autowired
	private DataSource dataSource;
	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate=new JdbcTemplate(dataSource);
	}
	public int bookAppointment(Appointment appointment) {
		int var=0;
		try {
			con = dataSource.getConnection();
			String sql = "insert into appointments(date_created, start_time, slot, end_time)values(?,?,?,?)";
			Object[] param=new Object[] {
				appointment.getDate_created(),
				appointment.getStart_time(),
				appointment.getSlot(),
				appointment.getEnd_time(),
			};
			jdbcTemplate.update(sql, param);
		} 
		catch (SQLException e1) {
			e1.printStackTrace();
			return var;
		}
		return var+1;
	}
}
