package com.yash.dams.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.yash.dams.model.Appointment;

public class AppointmentMapper implements RowMapper<Appointment> {

	public Appointment mapRow(ResultSet rs, int arg1) throws SQLException {
		Appointment appointment=new Appointment();
		appointment.setId(rs.getInt("id"));
		appointment.setCancel(rs.getInt("cancel"));
		appointment.setCancel_reason(rs.getString("cancel_reason"));
		appointment.setDate_created(rs.getDate("date_created"));
		appointment.setDiscount(rs.getString("discount"));
		appointment.setEnd_time(rs.getTime("end_time"));
		appointment.setEnd_time_expected(rs.getTime("end_time_expected"));
		appointment.setFee(rs.getString("fee"));
		appointment.setFinal_fee(rs.getString("final_fee"));
		appointment.setSlot(rs.getInt("slot"));
		appointment.setStart_time(rs.getTime("start_time"));
		appointment.setStatus(rs.getInt("status"));
		appointment.setUserid(rs.getInt("userid"));
		return appointment;
	}

}
