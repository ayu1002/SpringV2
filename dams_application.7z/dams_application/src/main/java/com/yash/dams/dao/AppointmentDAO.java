package com.yash.dams.dao;

import com.yash.dams.model.Appointment;

public interface AppointmentDAO {
	public int bookAppointment(Appointment appointment);
}
