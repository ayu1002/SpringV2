package com.yash.dams.dao;

import java.util.List;

import com.yash.dams.model.Appointment;

public interface AppointmentDAO {
	public int bookAppointment(Appointment appointment);
	public List<Appointment> showList();
	public List<Appointment> myBookings(Integer userid);
}
